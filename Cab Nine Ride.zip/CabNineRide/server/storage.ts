import { users, rides, driverLocations, type User, type InsertUser, type Ride, type InsertRide, type DriverLocation, type InsertDriverLocation } from "@shared/schema";
import { db } from "./db";
import { eq, or, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRides(userId?: string, role?: string): Promise<Ride[]>;
  createRide(ride: InsertRide): Promise<Ride>;
  updateRide(id: string, updates: Partial<Ride>): Promise<Ride | undefined>;
  getRideById(id: string): Promise<Ride | undefined>;
  
  updateDriverLocation(location: InsertDriverLocation): Promise<DriverLocation>;
  getAvailableDrivers(): Promise<DriverLocation[]>;
  getDriverLocation(driverId: string): Promise<DriverLocation | undefined>;
}

export class DatabaseStorage implements IStorage {

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getRides(userId?: string, role?: string): Promise<Ride[]> {
    if (userId && role === "passenger") {
      const result = await db.select().from(rides).where(eq(rides.passengerId, userId));
      return result.sort((a, b) => 
        new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
    } else if (userId && role === "driver") {
      const result = await db.select().from(rides).where(
        or(
          eq(rides.status, "pending"),
          and(
            eq(rides.driverId, userId),
            or(
              eq(rides.status, "assigned"),
              eq(rides.status, "in_progress")
            )
          )
        )
      );
      return result.sort((a, b) => 
        new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
    }
    
    // Admin or no filter - get all rides
    const result = await db.select().from(rides);
    return result.sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async createRide(insertRide: InsertRide): Promise<Ride> {
    const [ride] = await db
      .insert(rides)
      .values(insertRide)
      .returning();
    return ride;
  }

  async updateRide(id: string, updates: Partial<Ride>): Promise<Ride | undefined> {
    // Set timestamps based on status
    const finalUpdates = { ...updates };
    if (updates.status === "in_progress" && !finalUpdates.startedAt) {
      finalUpdates.startedAt = new Date();
    } else if (updates.status === "completed" && !finalUpdates.completedAt) {
      finalUpdates.completedAt = new Date();
    }

    const [updatedRide] = await db
      .update(rides)
      .set(finalUpdates)
      .where(eq(rides.id, id))
      .returning();
    return updatedRide || undefined;
  }

  async getRideById(id: string): Promise<Ride | undefined> {
    const [ride] = await db.select().from(rides).where(eq(rides.id, id));
    return ride || undefined;
  }

  async updateDriverLocation(insertLocation: InsertDriverLocation): Promise<DriverLocation> {
    const [location] = await db
      .insert(driverLocations)
      .values(insertLocation)
      .onConflictDoUpdate({
        target: driverLocations.driverId,
        set: {
          latitude: insertLocation.latitude,
          longitude: insertLocation.longitude,
          isOnline: insertLocation.isOnline,
          updatedAt: new Date(),
        },
      })
      .returning();
    return location;
  }

  async getAvailableDrivers(): Promise<DriverLocation[]> {
    return await db.select().from(driverLocations).where(eq(driverLocations.isOnline, true));
  }

  async getDriverLocation(driverId: string): Promise<DriverLocation | undefined> {
    const [location] = await db.select().from(driverLocations).where(eq(driverLocations.driverId, driverId));
    return location || undefined;
  }
}

export const storage = new DatabaseStorage();
