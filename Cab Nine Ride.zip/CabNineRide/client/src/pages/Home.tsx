import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { RideProvider } from "@/contexts/RideContext";
import PassengerInterface from "@/components/PassengerInterface";
import DriverInterface from "@/components/DriverInterface";
import AdminInterface from "@/components/AdminInterface";
import NotificationToast from "@/components/NotificationToast";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bell, User } from "lucide-react";

export default function Home() {
  const { currentUser, userProfile, loading, logout } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!currentUser) {
    window.location.href = "/login";
    return <div>Redirecting to login...</div>;
  }

  if (!userProfile) {
    return <div>Loading user profile...</div>;
  }

  function renderCurrentView() {
    switch (userProfile?.role) {
      case "driver":
        return <DriverInterface />;
      case "admin":
        return <AdminInterface />;
      default:
        return <PassengerInterface />;
    }
  }

  return (
    <RideProvider>
      <div className="min-h-screen bg-background">
        {/* Navigation Header */}
        <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-primary text-primary-foreground w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg">
              C9
            </div>
            <h1 className="text-xl font-semibold text-foreground">Cab9</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Current Role Display */}
            <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium capitalize">
              {userProfile?.role}
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Bell className="h-5 w-5 text-muted-foreground" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full"></div>
              </div>
              
              <Avatar className="h-8 w-8">
                <AvatarFallback>
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={logout}
                data-testid="button-logout"
              >
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="relative">
          {renderCurrentView()}
        </main>

        {/* Notifications */}
        <NotificationToast />
      </div>
    </RideProvider>
  );
}
