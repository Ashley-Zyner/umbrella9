import { createContext, useContext, useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./AuthContext";
import { Ride, InsertRide } from "@shared/schema";

interface RideContextType {
  rides: Ride[];
  currentRide: Ride | null;
  createRide: (rideData: Omit<InsertRide, 'passengerId'>) => Promise<void>;
  updateRideStatus: (rideId: string, status: string, additionalData?: Partial<Ride>) => Promise<void>;
  acceptRide: (rideId: string, driverId: string) => Promise<void>;
  loading: boolean;
}

const RideContext = createContext<RideContextType>({} as RideContextType);

export function useRide() {
  return useContext(RideContext);
}

export function RideProvider({ children }: { children: React.ReactNode }) {
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const { currentUser, userProfile } = useAuth();
  const queryClient = useQueryClient();

  // Fetch rides based on user role
  const { data: rides = [], isLoading: loading } = useQuery<Ride[]>({
    queryKey: ['/api/rides', { userId: currentUser?.uid, role: userProfile?.role }],
    enabled: !!currentUser && !!userProfile,
    refetchInterval: 3000, // Poll every 3 seconds for real-time updates
  });

  const createRideMutation = useMutation({
    mutationFn: async (rideData: Omit<InsertRide, 'passengerId'>) => {
      if (!currentUser) throw new Error("User must be logged in");
      
      const ride = {
        ...rideData,
        passengerId: currentUser.uid,
      };

      const response = await apiRequest('POST', '/api/rides', ride);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
    },
  });

  const updateRideMutation = useMutation({
    mutationFn: async ({ rideId, status, additionalData }: { 
      rideId: string; 
      status: string; 
      additionalData?: Partial<Ride> 
    }) => {
      const updateData: any = { status, ...additionalData };
      
      const response = await apiRequest('PATCH', `/api/rides/${rideId}`, updateData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
    },
  });

  async function createRide(rideData: Omit<InsertRide, 'passengerId'>) {
    await createRideMutation.mutateAsync(rideData);
  }

  async function updateRideStatus(rideId: string, status: string, additionalData?: Partial<Ride>) {
    await updateRideMutation.mutateAsync({ rideId, status, additionalData });
  }

  async function acceptRide(rideId: string, driverId: string) {
    await updateRideStatus(rideId, "assigned", { driverId });
  }

  // Update current ride when rides change
  useEffect(() => {
    if (!userProfile || !rides.length) {
      setCurrentRide(null);
      return;
    }

    // Set current ride for driver/passenger
    if (userProfile.role === "passenger") {
      const activeRide = rides.find(ride => 
        ["pending", "assigned", "in_progress"].includes(ride.status)
      );
      setCurrentRide(activeRide || null);
    } else if (userProfile.role === "driver") {
      const activeRide = rides.find(ride => 
        ride.driverId === currentUser?.uid && 
        ["assigned", "in_progress"].includes(ride.status)
      );
      setCurrentRide(activeRide || null);
    }
  }, [rides, userProfile, currentUser]);

  const value = {
    rides,
    currentRide,
    createRide,
    updateRideStatus,
    acceptRide,
    loading,
  };

  return (
    <RideContext.Provider value={value}>
      {children}
    </RideContext.Provider>
  );
}
