import MapSection from "@/components/MapSection";
import RideBookingCard from "@/components/RideBookingCard";

export default function PassengerInterface() {
  return (
    <div className="passenger-view">
      <MapSection />
      <RideBookingCard />
    </div>
  );
}
