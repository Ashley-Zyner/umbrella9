import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRide } from "@/contexts/RideContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import RideRequestCard from "@/components/RideRequestCard";
import { Power, Navigation, Phone, MapPin, Play, FlagIcon } from "lucide-react";

export default function DriverInterface() {
  const { userProfile } = useAuth();
  const { rides, currentRide, updateRideStatus } = useRide();
  const [isOnline, setIsOnline] = useState(true);

  const pendingRides = rides.filter(ride => ride.status === "pending");
  const availableRide = pendingRides[0]; // Show first pending ride

  async function handleToggleStatus() {
    setIsOnline(!isOnline);
    // TODO: Update driver online status in Firestore
  }

  async function handleTripAction(action: string) {
    if (!currentRide) return;

    switch (action) {
      case "arrive":
        await updateRideStatus(currentRide.id, "assigned");
        break;
      case "start":
        await updateRideStatus(currentRide.id, "in_progress");
        break;
      case "complete":
        await updateRideStatus(currentRide.id, "completed");
        break;
    }
  }

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Driver Status */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Driver Dashboard</h2>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-accent animate-pulse' : 'bg-gray-400'}`}></div>
              <span className={`text-sm font-medium ${isOnline ? 'text-accent' : 'text-gray-500'}`}>
                {isOnline ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground" data-testid="text-rides-today">0</div>
              <div className="text-sm text-muted-foreground">Rides Today</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground" data-testid="text-earnings-today">$0</div>
              <div className="text-sm text-muted-foreground">Earnings</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground" data-testid="text-rating">
                {userProfile?.rating || "0"}
              </div>
              <div className="text-sm text-muted-foreground">Rating</div>
            </div>
          </div>
          
          <Button 
            onClick={handleToggleStatus}
            className={`w-full ${isOnline ? 'bg-destructive hover:bg-destructive/90' : 'bg-accent hover:bg-accent/90'}`}
            data-testid="button-toggle-status"
          >
            <Power className="mr-2 h-4 w-4" />
            {isOnline ? 'Go Offline' : 'Go Online'}
          </Button>
        </CardContent>
      </Card>

      {/* Current Ride or Available Ride */}
      {currentRide ? (
        <Card className="border-2 border-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Trip in Progress</h3>
              <Badge variant="default" data-testid="badge-trip-status">
                {currentRide.status === "assigned" ? "En Route to Pickup" : "In Progress"}
              </Badge>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
                <div>
                  <div className="font-medium text-foreground" data-testid="text-pickup-location">
                    {currentRide.pickupLocation}
                  </div>
                  <div className="text-sm text-muted-foreground">Pickup</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-destructive rounded-full mt-2"></div>
                <div>
                  <div className="font-medium text-foreground" data-testid="text-dropoff-location">
                    {currentRide.dropoffLocation}
                  </div>
                  <div className="text-sm text-muted-foreground">Drop-off</div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-6">
              <Button variant="outline" data-testid="button-navigate">
                <Navigation className="mr-2 h-4 w-4" />
                Navigate
              </Button>
              <Button variant="outline" data-testid="button-call-passenger">
                <Phone className="mr-2 h-4 w-4" />
                Call
              </Button>
            </div>
            
            <div className="space-y-3">
              {currentRide.status === "assigned" && (
                <Button 
                  onClick={() => handleTripAction("arrive")}
                  className="w-full bg-accent text-accent-foreground"
                  data-testid="button-arrive-pickup"
                >
                  <MapPin className="mr-2 h-4 w-4" />
                  Arrived at Pickup
                </Button>
              )}
              
              {currentRide.status === "assigned" && (
                <Button 
                  onClick={() => handleTripAction("start")}
                  className="w-full"
                  data-testid="button-start-trip"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Start Trip
                </Button>
              )}
              
              {currentRide.status === "in_progress" && (
                <Button 
                  onClick={() => handleTripAction("complete")}
                  className="w-full bg-accent text-accent-foreground"
                  data-testid="button-complete-trip"
                >
                  <FlagIcon className="mr-2 h-4 w-4" />
                  Complete Trip
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ) : availableRide && isOnline ? (
        <RideRequestCard ride={availableRide} />
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-muted-foreground">
              {isOnline ? "No ride requests available" : "You are offline"}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
