import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRide } from "@/contexts/RideContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { User, X, Check } from "lucide-react";
import { Ride } from "@shared/schema";

interface RideRequestCardProps {
  ride: Ride;
}

export default function RideRequestCard({ ride }: RideRequestCardProps) {
  const { currentUser } = useAuth();
  const { acceptRide, updateRideStatus } = useRide();
  const { toast } = useToast();
  const [timeLeft, setTimeLeft] = useState(30);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      // Auto-decline after 30 seconds
      handleRejectRide();
    }
  }, [timeLeft]);

  async function handleAcceptRide() {
    if (!currentUser) return;
    
    try {
      setLoading(true);
      await acceptRide(ride.id, currentUser.uid);
      toast({
        title: "Ride Accepted",
        description: "Navigate to pickup location",
      });
    } catch (error: any) {
      toast({
        title: "Failed to Accept Ride",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  async function handleRejectRide() {
    try {
      setLoading(true);
      // Just ignore for now - in a real app, you'd track which drivers declined
      toast({
        title: "Ride Declined",
        description: "Looking for other available rides...",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="border-2 border-accent shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">New Ride Request</h3>
          <Badge className="bg-accent text-accent-foreground" data-testid="badge-eta">
            2 min away
          </Badge>
        </div>
        
        {/* Passenger Info */}
        <div className="flex items-center space-x-4 mb-4">
          <Avatar className="h-12 w-12">
            <AvatarFallback>
              <User className="h-6 w-6" />
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium text-foreground" data-testid="text-passenger-name">
              Passenger #{ride.passengerId.slice(0, 8)}
            </div>
            <div className="text-sm text-muted-foreground">★ 4.9 • Multiple rides</div>
          </div>
        </div>
        
        {/* Trip Details */}
        <div className="space-y-3 mb-6">
          <div className="flex items-start space-x-3">
            <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
            <div>
              <div className="font-medium text-foreground" data-testid="text-pickup-address">
                {ride.pickupLocation}
              </div>
              <div className="text-sm text-muted-foreground">Pickup in 2 min</div>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-3 h-3 bg-destructive rounded-full mt-2"></div>
            <div>
              <div className="font-medium text-foreground" data-testid="text-dropoff-address">
                {ride.dropoffLocation}
              </div>
              <div className="text-sm text-muted-foreground">
                {ride.estimatedDuration || "8 min"} trip
              </div>
            </div>
          </div>
        </div>
        
        {/* Trip Value */}
        <div className="bg-secondary rounded-lg p-4 mb-6">
          <div className="flex justify-between items-center">
            <span className="text-foreground font-medium">Trip Earnings</span>
            <span className="text-xl font-bold text-foreground" data-testid="text-earnings">
              ${ride.fare || "0.00"}
            </span>
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            {ride.distance || "2.3"}km • {ride.rideType} ride
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="flex space-x-3 mb-4">
          <Button
            onClick={handleRejectRide}
            disabled={loading}
            variant="destructive"
            className="flex-1"
            data-testid="button-decline-ride"
          >
            <X className="mr-2 h-4 w-4" />
            Decline
          </Button>
          <Button
            onClick={handleAcceptRide}
            disabled={loading}
            className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
            data-testid="button-accept-ride"
          >
            <Check className="mr-2 h-4 w-4" />
            Accept
          </Button>
        </div>
        
        {/* Auto-decline timer */}
        <div className="text-center">
          <div className="text-sm text-muted-foreground">
            Auto-decline in <span className="font-medium text-destructive" data-testid="text-timer">
              {timeLeft}
            </span> seconds
          </div>
          <div className="w-full bg-secondary rounded-full h-2 mt-2">
            <div 
              className="bg-destructive h-2 rounded-full transition-all duration-1000" 
              style={{ width: `${(timeLeft / 30) * 100}%` }}
            ></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
