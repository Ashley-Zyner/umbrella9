import { useState } from "react";
import { useRide } from "@/contexts/RideContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Car, Clock, Calendar, CheckCircle } from "lucide-react";

export default function RideBookingCard() {
  const [pickupLocation, setPickupLocation] = useState("");
  const [dropoffLocation, setDropoffLocation] = useState("");
  const [isNow, setIsNow] = useState(true);
  const [selectedRideType, setSelectedRideType] = useState("economy");
  const [loading, setLoading] = useState(false);
  
  const { createRide } = useRide();
  const { toast } = useToast();

  const rideTypes = [
    {
      id: "economy",
      name: "Economy",
      seats: "4 seats",
      price: "$12.50",
      eta: "2 min away",
      icon: Car,
    },
    {
      id: "premium",
      name: "Premium",
      seats: "4 seats", 
      price: "$18.75",
      eta: "5 min away",
      icon: Car,
    },
  ];

  async function handleBookRide() {
    if (!pickupLocation || !dropoffLocation) {
      toast({
        title: "Missing Information",
        description: "Please enter both pickup and drop-off locations",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);
      
      const rideType = rideTypes.find(type => type.id === selectedRideType);
      const fare = parseFloat(rideType?.price.replace('$', '') || "0");

      await createRide({
        pickupLocation,
        dropoffLocation,
        pickupLatLng: null,
        dropoffLatLng: null,
        rideType: selectedRideType,
        fare: fare,
        distance: 2.3, // TODO: Calculate actual distance
        estimatedDuration: "8 minutes",
        scheduledTime: isNow ? null : new Date(),
        driverId: null,
      });

      toast({
        title: "Ride Requested",
        description: "Looking for available drivers...",
      });

      // Reset form
      setPickupLocation("");
      setDropoffLocation("");
    } catch (error: any) {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="px-4 py-6 bg-card">
      <Card className="backdrop-blur-sm bg-white/95 border shadow-lg">
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Book Your Ride</h2>
          
          {/* Location Inputs */}
          <div className="space-y-4 mb-6 relative">
            <div className="relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
              </div>
              <Input
                type="text"
                placeholder="Pickup location"
                value={pickupLocation}
                onChange={(e) => setPickupLocation(e.target.value)}
                className="pl-10"
                data-testid="input-pickup-location"
              />
            </div>
            
            <div className="relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                <div className="w-3 h-3 bg-destructive rounded-full"></div>
              </div>
              <Input
                type="text"
                placeholder="Drop-off location"
                value={dropoffLocation}
                onChange={(e) => setDropoffLocation(e.target.value)}
                className="pl-10"
                data-testid="input-dropoff-location"
              />
            </div>
            
            {/* Connecting line */}
            <div className="absolute left-7 top-6 w-0.5 h-8 bg-border"></div>
          </div>
          
          {/* Time Selection */}
          <div className="mb-6">
            <Label className="text-sm font-medium text-foreground mb-2 block">
              When do you need this ride?
            </Label>
            <div className="flex space-x-3">
              <Button
                onClick={() => setIsNow(true)}
                variant={isNow ? "default" : "outline"}
                className="flex-1"
                data-testid="button-ride-now"
              >
                <Clock className="mr-2 h-4 w-4" />
                Now
              </Button>
              <Button
                onClick={() => setIsNow(false)}
                variant={!isNow ? "default" : "outline"}
                className="flex-1"
                data-testid="button-schedule-ride"
              >
                <Calendar className="mr-2 h-4 w-4" />
                Schedule
              </Button>
            </div>
          </div>
          
          {/* Ride Type Selection */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-foreground mb-3">Choose ride type</h3>
            <div className="grid grid-cols-2 gap-3">
              {rideTypes.map((type) => {
                const Icon = type.icon;
                const isSelected = selectedRideType === type.id;
                
                return (
                  <div
                    key={type.id}
                    onClick={() => setSelectedRideType(type.id)}
                    className={`p-4 rounded-lg cursor-pointer transition-all hover:-translate-y-1 ${
                      isSelected
                        ? "border-2 border-primary bg-primary/5"
                        : "border border-border bg-card"
                    }`}
                    data-testid={`card-ride-type-${type.id}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">{type.name}</span>
                      <Icon className={`h-4 w-4 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                    </div>
                    <div className="text-sm text-muted-foreground">{type.seats}</div>
                    <div className={`text-lg font-bold ${isSelected ? "text-primary" : "text-foreground"}`}>
                      {type.price}
                    </div>
                    <div className="text-xs text-muted-foreground">{type.eta}</div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Book Ride Button */}
          <Button
            onClick={handleBookRide}
            disabled={loading}
            className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-12 text-lg font-semibold"
            data-testid="button-book-ride"
          >
            <CheckCircle className="mr-2 h-5 w-5" />
            {loading ? "Booking Ride..." : "Book Ride"}
          </Button>
          
          {/* Price estimate */}
          <div className="mt-3 text-center text-sm text-muted-foreground">
            Estimated trip time: 8 minutes • Distance: 2.3 km
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
