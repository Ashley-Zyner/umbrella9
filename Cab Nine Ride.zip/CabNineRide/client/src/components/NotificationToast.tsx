import { useState, useEffect } from "react";
import { useRide } from "@/contexts/RideContext";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, X } from "lucide-react";

interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
}

export default function NotificationToast() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentNotification, setCurrentNotification] = useState<Notification | null>(null);
  const { rides } = useRide();
  const { userProfile } = useAuth();

  useEffect(() => {
    if (rides.length === 0) return;

    const latestRide = rides[0];
    
    // Create notifications based on user role and ride status
    if (userProfile?.role === "driver" && latestRide.status === "pending") {
      showNotification(
        "New Ride Request",
        `Ride request from passenger`
      );
    } else if (userProfile?.role === "passenger" && latestRide.status === "assigned") {
      showNotification(
        "Driver Assigned",
        "Your driver is on the way!"
      );
    } else if (userProfile?.role === "admin" && latestRide.status === "pending") {
      showNotification(
        "New Ride",
        "New ride request needs assignment"
      );
    }
  }, [rides, userProfile]);

  function showNotification(title: string, message: string) {
    const notification: Notification = {
      id: Date.now().toString(),
      title,
      message,
      timestamp: new Date(),
    };

    setNotifications(prev => [notification, ...prev.slice(0, 4)]);
    setCurrentNotification(notification);

    // Auto-hide after 5 seconds
    setTimeout(() => {
      setCurrentNotification(null);
    }, 5000);
  }

  function dismissNotification() {
    setCurrentNotification(null);
  }

  if (!currentNotification) return null;

  return (
    <Card className="fixed top-20 right-4 w-80 z-50 shadow-lg animate-in slide-in-from-right">
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
            <Bell className="h-4 w-4 text-accent-foreground" />
          </div>
          <div className="flex-1">
            <div className="font-medium text-foreground" data-testid="text-notification-title">
              {currentNotification.title}
            </div>
            <div className="text-sm text-muted-foreground" data-testid="text-notification-message">
              {currentNotification.message}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {currentNotification.timestamp.toLocaleTimeString()}
            </div>
          </div>
          <Button
            onClick={dismissNotification}
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0"
            data-testid="button-dismiss-notification"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
