import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRide } from "@/contexts/RideContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { RefreshCw, MapPin, User } from "lucide-react";

export default function AdminInterface() {
  const { currentUser } = useAuth();
  const { rides, acceptRide } = useRide();
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedDriver, setSelectedDriver] = useState<string>("");

  const filteredRides = rides.filter(ride => 
    statusFilter === "all" || ride.status === statusFilter
  );

  const stats = {
    active: rides.filter(ride => ["pending", "assigned", "in_progress"].includes(ride.status)).length,
    pending: rides.filter(ride => ride.status === "pending").length,
    completed: rides.filter(ride => ride.status === "completed").length,
  };

  function getStatusColor(status: string) {
    switch (status) {
      case "pending": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "assigned": return "bg-blue-100 text-blue-800 border-blue-200";
      case "in_progress": return "bg-purple-100 text-purple-800 border-purple-200";
      case "completed": return "bg-green-100 text-green-800 border-green-200";
      case "cancelled": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  }

  function getStatusBorderColor(status: string) {
    switch (status) {
      case "pending": return "border-l-yellow-500";
      case "assigned": return "border-l-blue-500";
      case "in_progress": return "border-l-purple-500";
      case "completed": return "border-l-green-500";
      case "cancelled": return "border-l-red-500";
      default: return "border-l-gray-500";
    }
  }

  async function handleAssignDriver(rideId: string) {
    if (!selectedDriver) return;
    await acceptRide(rideId, selectedDriver);
    setSelectedDriver("");
  }

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Admin Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-foreground">Admin Dashboard</h2>
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="text-lg font-bold text-foreground" data-testid="text-active-rides">
                  {stats.active}
                </div>
                <div className="text-xs text-muted-foreground">Active</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-foreground" data-testid="text-pending-rides">
                  {stats.pending}
                </div>
                <div className="text-xs text-muted-foreground">Pending</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-foreground" data-testid="text-completed-rides">
                  {stats.completed}
                </div>
                <div className="text-xs text-muted-foreground">Completed</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40" data-testid="select-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Rides</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="assigned">Assigned</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="sm" data-testid="button-refresh">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Rides List */}
      <div className="space-y-4">
        {filteredRides.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No rides found
            </CardContent>
          </Card>
        ) : (
          filteredRides.map((ride) => (
            <Card key={ride.id} className={`border-l-4 ${getStatusBorderColor(ride.status)}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge className={getStatusColor(ride.status)} data-testid={`badge-status-${ride.id}`}>
                        {ride.status}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {ride.createdAt && new Date(ride.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="font-medium text-foreground" data-testid={`text-passenger-${ride.id}`}>
                      Passenger #{ride.passengerId.slice(0, 8)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {ride.rideType} • {ride.fare ? `$${ride.fare}` : 'Fare pending'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-foreground" data-testid={`text-fare-${ride.id}`}>
                      ${ride.fare || "0.00"}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {ride.distance ? `${ride.distance}km` : 'Distance pending'}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm text-foreground" data-testid={`text-pickup-${ride.id}`}>
                      {ride.pickupLocation}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-destructive rounded-full"></div>
                    <span className="text-sm text-foreground" data-testid={`text-dropoff-${ride.id}`}>
                      {ride.dropoffLocation}
                    </span>
                  </div>
                </div>

                {/* Driver Info (if assigned) */}
                {ride.driverId && (
                  <div className="flex items-center space-x-3 mb-4 bg-secondary rounded-lg p-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>
                        <User className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium text-foreground" data-testid={`text-driver-${ride.id}`}>
                        Driver #{ride.driverId.slice(0, 8)}
                      </div>
                      <div className="text-sm text-muted-foreground">Assigned Driver</div>
                    </div>
                    <Button variant="outline" size="sm" data-testid={`button-track-${ride.id}`}>
                      <MapPin className="mr-1 h-3 w-3" />
                      Track
                    </Button>
                  </div>
                )}

                {/* Manual Assignment (for pending rides) */}
                {ride.status === "pending" && (
                  <div className="flex items-center space-x-3">
                    <Select 
                      value={selectedDriver} 
                      onValueChange={setSelectedDriver}
                    >
                      <SelectTrigger className="flex-1" data-testid={`select-driver-${ride.id}`}>
                        <SelectValue placeholder="Select driver to assign" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="driver1">Driver #ABC123 (4.9★) - 1.2km away</SelectItem>
                        <SelectItem value="driver2">Driver #DEF456 (4.8★) - 2.1km away</SelectItem>
                        <SelectItem value="driver3">Driver #GHI789 (4.7★) - 0.8km away</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={() => handleAssignDriver(ride.id)}
                      disabled={!selectedDriver}
                      data-testid={`button-assign-${ride.id}`}
                    >
                      Assign
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
