import { Button } from "@/components/ui/button";
import { Crosshair, Car } from "lucide-react";

export default function MapSection() {
  function handleCenterMap() {
    // TODO: Center map on user location
    console.log("Centering map on user location");
  }

  return (
    <div className="relative h-96 bg-gradient-to-br from-blue-500 to-purple-600">
      {/* Map placeholder */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="text-4xl mb-2">🗺️</div>
          <p className="text-lg font-medium">Interactive Map</p>
          <p className="text-sm opacity-80">Google Maps integration coming soon</p>
        </div>
      </div>
      
      {/* Mock driver markers */}
      <div className="absolute top-20 left-16 w-8 h-8 bg-accent rounded-full border-2 border-white flex items-center justify-center text-white">
        <Car className="h-4 w-4" />
      </div>
      <div className="absolute top-32 right-20 w-8 h-8 bg-accent rounded-full border-2 border-white flex items-center justify-center text-white">
        <Car className="h-4 w-4" />
      </div>
      <div className="absolute bottom-20 left-1/3 w-8 h-8 bg-accent rounded-full border-2 border-white flex items-center justify-center text-white">
        <Car className="h-4 w-4" />
      </div>
      
      {/* Current location pin */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="w-6 h-6 bg-destructive rounded-full border-2 border-white"></div>
        <div className="w-1 h-8 bg-destructive mx-auto"></div>
      </div>
      
      {/* My Location Button */}
      <Button 
        onClick={handleCenterMap}
        className="absolute bottom-4 right-4 w-12 h-12 rounded-full p-0"
        variant="secondary"
        data-testid="button-center-map"
      >
        <Crosshair className="h-5 w-5" />
      </Button>
    </div>
  );
}
