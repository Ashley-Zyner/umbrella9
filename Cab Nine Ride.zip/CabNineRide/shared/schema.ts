import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  role: text("role").notNull().default("passenger"), // passenger, driver, admin
  phone: text("phone"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const rides = pgTable("rides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  passengerId: varchar("passenger_id").notNull().references(() => users.id),
  driverId: varchar("driver_id").references(() => users.id),
  pickupLocation: text("pickup_location").notNull(),
  dropoffLocation: text("dropoff_location").notNull(),
  pickupLatLng: json("pickup_lat_lng"), // {lat: number, lng: number}
  dropoffLatLng: json("dropoff_lat_lng"), // {lat: number, lng: number}
  status: text("status").notNull().default("pending"), // pending, assigned, in_progress, completed, cancelled
  rideType: text("ride_type").notNull().default("economy"), // economy, premium
  fare: decimal("fare", { precision: 10, scale: 2 }).$type<number>(),
  distance: decimal("distance", { precision: 10, scale: 2 }).$type<number>(), // in km
  estimatedDuration: text("estimated_duration"), // in minutes
  scheduledTime: timestamp("scheduled_time"),
  createdAt: timestamp("created_at").defaultNow(),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
});

export const driverLocations = pgTable("driver_locations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  driverId: varchar("driver_id").notNull().references(() => users.id).unique(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).$type<number>().notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).$type<number>().notNull(),
  isOnline: boolean("is_online").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertRideSchema = createInsertSchema(rides).omit({
  id: true,
  createdAt: true,
  startedAt: true,
  completedAt: true,
});

export const insertDriverLocationSchema = createInsertSchema(driverLocations).omit({
  id: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertRide = z.infer<typeof insertRideSchema>;
export type Ride = typeof rides.$inferSelect;
export type InsertDriverLocation = z.infer<typeof insertDriverLocationSchema>;
export type DriverLocation = typeof driverLocations.$inferSelect;
