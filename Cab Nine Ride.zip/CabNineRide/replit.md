# Overview

Cab9 is a ride-sharing platform built with a modern full-stack architecture. It provides a complete taxi/ride-hailing service with separate interfaces for passengers, drivers, and administrators. The application handles ride booking, real-time driver tracking, ride management, and user authentication across multiple user roles.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built using React 18 with TypeScript, utilizing a component-based architecture. The UI is constructed with shadcn/ui components built on top of Radix UI primitives and styled with Tailwind CSS. The application uses Wouter for client-side routing and React Query (TanStack Query) for server state management. Context providers handle authentication and ride state management across components.

## Backend Architecture
The server is built with Express.js and TypeScript, following a RESTful API design pattern. The application uses an in-memory storage implementation that can be easily swapped for a database layer. The server includes middleware for request logging, error handling, and serves both API endpoints and static assets in production.

## Database Design
The schema is defined using Drizzle ORM with PostgreSQL as the target database. Core entities include:
- Users table with role-based access (passenger, driver, admin)
- Rides table tracking the complete ride lifecycle
- Driver locations table for real-time positioning
The schema includes proper relationships, constraints, and default values using PostgreSQL-specific features.

## Authentication & Authorization
The application implements Firebase Authentication for user management, with custom user profiles stored in Firestore. Role-based access control differentiates between passengers, drivers, and administrators, with each role having distinct UI interfaces and permissions.

## State Management
Client-side state is managed through React Context for authentication and ride data, with React Query handling server synchronization. The application maintains real-time updates through periodic polling and optimistic updates for better user experience.

## Build System
Vite is used as the build tool and development server, with separate build processes for client and server code. The client builds to static assets while the server is bundled using esbuild for production deployment. Hot module replacement is enabled in development with additional Replit-specific plugins.

## Component Architecture
The UI follows a modular component structure with:
- Role-specific interfaces (PassengerInterface, DriverInterface, AdminInterface)
- Reusable UI components from shadcn/ui
- Custom business logic components for ride booking, driver tracking, and admin management
- Responsive design with mobile-first approach

# External Dependencies

## Database & ORM
- **Drizzle ORM**: Type-safe database operations and migrations
- **Neon Database**: PostgreSQL hosting (serverless)
- **connect-pg-simple**: PostgreSQL session store

## Authentication
- **Firebase**: User authentication and Firestore database for user profiles

## UI Framework
- **React**: Frontend framework with hooks and context
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling
- **Lucide React**: Icon library

## State Management & API
- **TanStack React Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across frontend and backend
- **ESBuild**: Fast server-side bundling for production

## Replit Integration
- **@replit/vite-plugin-***: Development experience plugins for Replit environment